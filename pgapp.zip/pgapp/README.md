# NestFinder — PG Management Platform

A full-stack PG (Paying Guest) management platform with role-based access for Users, Agents, and Owners.

## 🚀 Quick Start

```bash
cd pgapp
pip install flask
python app.py
```
Then open: http://localhost:5050

---

## 🔐 Login Credentials

### Users (userinfo.json)
| Username | Password   |
|----------|------------|
| ravi     | ravi123    |
| priya    | priya456   |
| suresh   | suresh789  |

### Agents (agentinfo.json)
| Agent Name | Password     |
|------------|--------------|
| krishna    | krishna123   |
| lakshmi    | lakshmi456   |
| venkat     | venkat789    |

### Owner
Any username + any password — full admin access.

---

## 📁 Project Structure

```
pgapp/
├── app.py              ← Flask backend (all logic here, not visible to browser)
├── requirements.txt
├── run.sh
├── data/
│   ├── userinfo.json   ← User credentials
│   ├── agentinfo.json  ← Agent credentials
│   ├── pglistings.json ← All PG data (auto-created)
│   └── activitylog.json← All activity logs (auto-created)
├── static/
│   └── uploads/        ← Cover photos stored here
└── templates/
    └── index.html      ← Full SPA frontend
```

---

## 🌟 Features

### User
- Login with credentials from userinfo.json
- Search PGs by town name
- See all available PGs with cover photo, name, price
- View full PG details: rooms, vacancies, amenities

### Agent
- Login with credentials from agentinfo.json
- See history of all their PG listings
- Add new PG: cover photo, name, town, address, description, amenities
- Add rooms: AC/Non-AC, capacity, price
- Add residents per room: name, phone, ID number
- Track rent payment per resident per month (click months to toggle)
- Edit everything — all changes reflect to users immediately

### Owner
- Login with any credentials
- Full stats dashboard: total PGs, agents, users, rooms, residents, rent status
- Activity log: every login, PG creation, update
- All PG listings overview
- Full rent tracker with month-by-month payment status per resident

---

## 🛡️ Why Python Backend?

The Flask backend serves the HTML/CSS/JS but keeps all business logic, data access, and file paths on the server side. Anyone who "View Source" in browser only sees the frontend JS — no file paths, no credentials, no data logic. The actual data lives in JSON files on the server, inaccessible to browser inspection.

---

## ✏️ Customizing Credentials

Edit `data/userinfo.json` to add/remove users:
```json
[
  {"username": "yourname", "password": "yourpassword"}
]
```

Edit `data/agentinfo.json` to add/remove agents:
```json
[
  {"agentname": "agentname", "password": "password"}
]
```
