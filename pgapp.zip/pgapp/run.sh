#!/bin/bash
# NestFinder PG Management Platform
# ===================================

echo "Installing dependencies..."
pip install flask --break-system-packages -q

echo "Starting NestFinder on http://localhost:5050"
python app.py
