from flask import Flask, request, jsonify, session, send_from_directory, render_template
import json, os, uuid, base64
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = "pgapp_super_secret_2024_silicofeller"

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

def load_json(filename):
    path = os.path.join(DATA_DIR, filename)
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        return json.load(f)

def save_json(filename, data):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def log_activity(actor, actor_type, action, details=""):
    logs = load_json("activitylog.json")
    logs.append({
        "id": str(uuid.uuid4()),
        "actor": actor,
        "actor_type": actor_type,
        "action": action,
        "details": details,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    save_json("activitylog.json", logs)

# ─── Serve Main App ───────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")

# ─── USER AUTH ────────────────────────────────────────────────────
@app.route("/api/user/login", methods=["POST"])
def user_login():
    data = request.json
    users = load_json("userinfo.json")
    for u in users:
        if u["username"] == data.get("username") and u["password"] == data.get("password"):
            session["user"] = u["username"]
            session["role"] = "user"
            log_activity(u["username"], "user", "login")
            return jsonify({"success": True, "username": u["username"]})
    return jsonify({"success": False, "message": "Invalid username or password"}), 401

# ─── AGENT AUTH ───────────────────────────────────────────────────
@app.route("/api/agent/login", methods=["POST"])
def agent_login():
    data = request.json
    agents = load_json("agentinfo.json")
    for a in agents:
        if a["agentname"] == data.get("agentname") and a["password"] == data.get("password"):
            session["agent"] = a["agentname"]
            session["role"] = "agent"
            log_activity(a["agentname"], "agent", "login")
            return jsonify({"success": True, "agentname": a["agentname"]})
    return jsonify({"success": False, "message": "Invalid agent name or password"}), 401

# ─── OWNER AUTH ───────────────────────────────────────────────────
@app.route("/api/owner/login", methods=["POST"])
def owner_login():
    data = request.json
    # Owner can log in with ANY credentials — just track who they are
    if data.get("username") and data.get("password"):
        session["owner"] = data.get("username")
        session["role"] = "owner"
        log_activity(data.get("username"), "owner", "login")
        return jsonify({"success": True, "username": data.get("username")})
    return jsonify({"success": False, "message": "Enter username and password"}), 400

# ─── USER: search PGs by town ─────────────────────────────────────
@app.route("/api/pgs/search", methods=["GET"])
def search_pgs():
    town = request.args.get("town", "").strip().lower()
    pgs = load_json("pglistings.json")
    results = [pg for pg in pgs if pg.get("town", "").lower() == town]
    return jsonify(results)

# ─── USER: get single PG details ──────────────────────────────────
@app.route("/api/pgs/<pg_id>", methods=["GET"])
def get_pg(pg_id):
    pgs = load_json("pglistings.json")
    for pg in pgs:
        if pg["id"] == pg_id:
            return jsonify(pg)
    return jsonify({"error": "Not found"}), 404

# ─── AGENT: get all PGs by agent ──────────────────────────────────
@app.route("/api/agent/pgs", methods=["GET"])
def agent_pgs():
    agentname = request.args.get("agentname")
    pgs = load_json("pglistings.json")
    results = [pg for pg in pgs if pg.get("agent") == agentname]
    return jsonify(results)

# ─── AGENT: save cover photo (base64) ────────────────────────────
@app.route("/api/upload/cover", methods=["POST"])
def upload_cover():
    data = request.json
    b64 = data.get("image", "")
    if "," in b64:
        b64 = b64.split(",")[1]
    filename = f"cover_{uuid.uuid4().hex}.jpg"
    filepath = os.path.join(UPLOAD_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(base64.b64decode(b64))
    return jsonify({"url": f"/static/uploads/{filename}"})

# ─── AGENT: create new PG ─────────────────────────────────────────
@app.route("/api/agent/pgs", methods=["POST"])
def create_pg():
    data = request.json
    pgs = load_json("pglistings.json")
    pg_id = str(uuid.uuid4())
    pg = {
        "id": pg_id,
        "agent": data.get("agent"),
        "pg_name": data.get("pg_name", ""),
        "town": data.get("town", "").strip().lower(),
        "address": data.get("address", ""),
        "description": data.get("description", ""),
        "cover_photo": data.get("cover_photo", ""),
        "amenities": data.get("amenities", []),
        "rooms": data.get("rooms", []),
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    pgs.append(pg)
    save_json("pglistings.json", pgs)
    log_activity(data.get("agent"), "agent", "create_pg", f"PG: {data.get('pg_name')} in {data.get('town')}")
    return jsonify({"success": True, "id": pg_id})

# ─── AGENT: update PG ─────────────────────────────────────────────
@app.route("/api/agent/pgs/<pg_id>", methods=["PUT"])
def update_pg(pg_id):
    data = request.json
    pgs = load_json("pglistings.json")
    for i, pg in enumerate(pgs):
        if pg["id"] == pg_id:
            data["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            data["id"] = pg_id
            data["agent"] = pg["agent"]
            data["created_at"] = pg["created_at"]
            pgs[i] = {**pg, **data}
            save_json("pglistings.json", pgs)
            log_activity(pg["agent"], "agent", "update_pg", f"PG: {pg.get('pg_name')}")
            return jsonify({"success": True})
    return jsonify({"error": "Not found"}), 404

# ─── AGENT: update room residents & rent ──────────────────────────
@app.route("/api/agent/pgs/<pg_id>/rooms/<room_id>", methods=["PUT"])
def update_room(pg_id, room_id):
    data = request.json
    pgs = load_json("pglistings.json")
    for pg in pgs:
        if pg["id"] == pg_id:
            for room in pg.get("rooms", []):
                if room["id"] == room_id:
                    room.update(data)
                    pg["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    save_json("pglistings.json", pgs)
                    log_activity(pg["agent"], "agent", "update_room", f"PG: {pg.get('pg_name')}, Room: {room_id}")
                    return jsonify({"success": True})
    return jsonify({"error": "Not found"}), 404

# ─── OWNER: full activity log ─────────────────────────────────────
@app.route("/api/owner/logs", methods=["GET"])
def owner_logs():
    logs = load_json("activitylog.json")
    return jsonify(list(reversed(logs)))

# ─── OWNER: all PG data ───────────────────────────────────────────
@app.route("/api/owner/pgs", methods=["GET"])
def owner_pgs():
    pgs = load_json("pglistings.json")
    return jsonify(pgs)

# ─── OWNER: stats ─────────────────────────────────────────────────
@app.route("/api/owner/stats", methods=["GET"])
def owner_stats():
    pgs = load_json("pglistings.json")
    logs = load_json("activitylog.json")
    agents = load_json("agentinfo.json")
    users = load_json("userinfo.json")
    total_rooms = sum(len(pg.get("rooms", [])) for pg in pgs)
    total_persons = sum(
        len(room.get("persons", []))
        for pg in pgs for room in pg.get("rooms", [])
    )
    paid = sum(
        1 for pg in pgs for room in pg.get("rooms", [])
        for person in room.get("persons", [])
        if person.get("current_month_paid")
    )
    return jsonify({
        "total_pgs": len(pgs),
        "total_agents": len(agents),
        "total_users": len(users),
        "total_rooms": total_rooms,
        "total_persons": total_persons,
        "paid_this_month": paid,
        "unpaid_this_month": total_persons - paid,
        "recent_logs": list(reversed(logs))[:20]
    })

# ─── Logout ───────────────────────────────────────────────────────
@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"success": True})

if __name__ == "__main__":
    app.run(debug=True, port=5050)
